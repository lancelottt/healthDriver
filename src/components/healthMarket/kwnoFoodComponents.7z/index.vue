<template>
	<div class="knowFoodIndex">
		111
	</div>
</template>
<script type="text/javascript">
	export default{
		
		
	}
</script>
<style type="text/css">
	
</style>