<template>
	<div class="knowFoodVegetable">
		333
	</div>
</template>
<script type="text/javascript">
	export default{
		
		
	}
</script>
<style type="text/css">
	
</style>