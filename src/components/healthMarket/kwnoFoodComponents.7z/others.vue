<template>
	<div class="knowFoodOthers">
		5555
	</div>
</template>
<script type="text/javascript">
	export default{
		
		
	}
</script>
<style type="text/css">
	
</style>